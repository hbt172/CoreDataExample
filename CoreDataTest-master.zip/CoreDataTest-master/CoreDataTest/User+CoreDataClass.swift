//
//  User+CoreDataClass.swift
//  CoreDataTest
//
//  Created by Krzysztof Kempiński on 17.04.2018.
//  Copyright © 2018 test. All rights reserved.
//
//

import Foundation
import CoreData

@objc(User)
public class User: NSManagedObject {

}
