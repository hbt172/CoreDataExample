//
//  ViewController.swift
//  CoreDataExample
//
//  Created by Nirav Joshi on 29/09/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit
import CoreData
class ViewController: UIViewController {
    let mainContext = AppDelegate.mainDelegate().persistentContainer.viewContext
    override func viewDidLoad() {
        super.viewDidLoad()
        let users = User(entity: NSEntityDescription.entity(forEntityName: "User", in: mainContext)!, insertInto: mainContext)
        users.name = "john"
        users.email = "john@gmail.com"
        
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy/MM/dd"
        let date = formatter.date(from: "1990/10/08")
        users.date_of_birth = date
        users.number_of_children = 20
        
        
        
        
        let cars = Cars(entity: NSEntityDescription.entity(forEntityName: "Cars", in: mainContext)!, insertInto: mainContext)
        cars.model = "Swift"
        cars.year = 2018
        cars.user = users
        
        let cars2 = Cars(entity: NSEntityDescription.entity(forEntityName: "Cars", in: mainContext)!, insertInto: mainContext)
        cars2.model = "Swift1"
        cars2.year = 2019
        cars2.user = users
        
        do {
            try  mainContext.save()
        } catch let error as NSError {
            print("Could not save. \(error), \(error._userInfo!)")
        }
        
        let userFetch = NSFetchRequest<NSFetchRequestResult>(entityName: "User")
       userFetch.fetchLimit = 1
        userFetch.predicate = NSPredicate(format: "name = %@", "john")
        userFetch.sortDescriptors = [NSSortDescriptor.init(key: "email", ascending: true)]
        let users1 = try! mainContext.fetch(userFetch)
        let john: User = users1.first as! User
        print("Email: \(john.email!)")
//        let johnCars = john.cars?.allObjects as! [Cars]
//        print("has \(johnCars.count)")
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

